import pygame, sys
from settings import *
from level import Level

class Game:
    def __init__(self):

        # general setup
        pygame.init()
        self.screen = pygame.display.set_mode((WIDTH, HEIGTH))
        pygame.display.set_caption('ASHVATTAH')
        self.clock = pygame.time.Clock()

        self.level = Level()

        # sound
        main_sound = pygame.mixer.Sound('../audio/main.ogg')
        main_sound.set_volume(0.5)
        main_sound.play(loops=-1)

        # game state
        self.show_synopsis = True
        self.synopsis_text = (
            "Ashvattah\nMenceritakan petualangan anak yang mencari kembaransnya\n"
            "yang diculik oleh dewa dari suatu negeri.\n\n\n\n tekan tombol apapun untuk memulai game"
        )
        self.current_synopsis = ""
        self.synopsis_index = 0
        self.type_speed = FPS  # Number of frames to wait before adding the next character

    def display_synopsis(self):
        # Set up fonts
        font = pygame.font.Font(None, 36)
        text_color = (255, 255, 255)  # white

        # Animate typing
        if self.synopsis_index < len(self.synopsis_text):
            self.synopsis_index += 1
            self.current_synopsis = self.synopsis_text[:self.synopsis_index]

        # Display the text
        self.screen.fill((0, 0, 0))  # black background
        lines = self.current_synopsis.split('\n')
        for i, line in enumerate(lines):
            text_surface = font.render(line, True, text_color)
            text_rect = text_surface.get_rect(center=(WIDTH // 2, HEIGTH // 2 - 50 + i * 40))
            self.screen.blit(text_surface, text_rect)

        pygame.display.update()

    def run(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if self.show_synopsis and event.type == pygame.KEYDOWN:
                    self.show_synopsis = False

            if self.show_synopsis:
                self.display_synopsis()
            else:
                self.screen.fill(WATER_COLOR)
                self.level.run()
                pygame.display.update()
                self.clock.tick(FPS)
            # Control the typing speed
            self.clock.tick(self.type_speed)

if __name__ == '__main__':
    game = Game()
    game.run()
